package com.foodordering.auth.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foodordering.auth.Dto.LoginRequest;
import com.foodordering.auth.Dto.RegisterReguest;
import com.foodordering.auth.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;




@RestController
@RequestMapping("/auth")
public class UserController {

    @Autowired
    UserService userservice;

    @PostMapping("/Register")
    public String Register(@RequestBody RegisterReguest dto) {
        
        return userservice.Register(dto);
    }

    @PostMapping("/login")
    public String Login(@RequestBody LoginRequest dto) {

        return userservice.Login(dto);
    }
    
    
}