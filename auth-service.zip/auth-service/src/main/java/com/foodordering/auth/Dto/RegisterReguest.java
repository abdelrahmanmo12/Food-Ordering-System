package com.foodordering.auth.Dto;

public class RegisterReguest {
    public String username;
    public String password;
    public String role;
}