package com.foodordering.auth.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.foodordering.auth.Dto.LoginRequest;
import com.foodordering.auth.Dto.RegisterReguest;
import com.foodordering.auth.Model.user;
import com.foodordering.auth.Repo.UserRepo;

@Service
public class UserService {

    @Autowired
    UserRepo userrepo;

    @Autowired
    PasswordEncoder passwordEncoder;

   @Autowired
   JwtService jwtService; 

    public String Register(RegisterReguest dto){
        user user = new user();

        user.setUsername(dto.username);
        
        user.setPassword(passwordEncoder.encode(dto.password));
        
        user.setRole(dto.role.toUpperCase());
        
        userrepo.save(user);

        return "registered successfully";
    }

    public String Login(LoginRequest dto){
        
        user user = userrepo.findByUsername(dto.username);
        if(user == null){
            return "username not found";
        }

        if(!passwordEncoder.matches(dto.password, user.getPassword())){
            return "password is wrong";
        }
        return jwtService.generateToken(user.getUsername(), user.getRole());
    }
}