package com.foodordering.auth.Dto;

public class LoginRequest {
    public String username;
    public String password;
}