package com.foodordering.auth.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.foodordering.auth.Model.user;

@Repository
public interface UserRepo extends JpaRepository<user, Integer>{

    user findByUsername(String username);

}