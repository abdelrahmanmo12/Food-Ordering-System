package com.foodordering.gateway.config;

import com.foodordering.gateway.dto.ValidationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator validator;

    @Autowired
    private WebClient.Builder webClientBuilder; 

    public AuthenticationFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            if (validator.isSecured.test(exchange.getRequest())) {
                
                if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                    throw new RuntimeException("Missing authorization header");
                }

                String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);

                return webClientBuilder.build()
                        .post()
                        .uri("http://AUTH-SERVICE/auth/validate")
                        .header(HttpHeaders.AUTHORIZATION, authHeader)
                        .retrieve()
                        .bodyToMono(ValidationResponse.class)
                        .flatMap(response -> {
                            if (response == null || !response.isValid()) {
                                return Mono.error(new RuntimeException("Unauthorized access to application"));
                            }
                            System.out.println("DEBUG: Role from Auth: " + response.getRole());
                            System.out.println("DEBUG: AccountID from Auth: " + response.getAccountId());

                            ServerHttpRequest modifiedRequest = exchange.getRequest().mutate()
                                    .header("X-User-Id", String.valueOf(response.getAccountId()))
                                    .header("X-User-Role", response.getRole())
                                    .build();

                            System.out.println("Headers added successfully!");

                            return chain.filter(exchange.mutate().request(modifiedRequest).build());
                        });
            }
            return chain.filter(exchange);
        };
    }

    public static class Config {
    }
}