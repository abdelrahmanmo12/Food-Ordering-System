package com.foodordering.gateway.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ValidationResponse {
    private boolean isValid;
    private String role;
    private String status;
    private Long accountId;
    public ValidationResponse(boolean isValid, String role, String status, Long accountId) {
        this.isValid = isValid;
        this.role = role;
        this.status = status;
        this.accountId = accountId;
    }

}